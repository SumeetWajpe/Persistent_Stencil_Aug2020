class Tooltip extends HTMLElement{
    tooltip=null;
    toolTipText ="Some dummy Tooptip"; 
    constructor(){
        super();     
        this.attachShadow({mode:'open'});         
    }
    connectedCallback(){
        if(this.hasAttribute('text')){
            this.toolTipText = this.getAttribute('text');
        }
        const tooltipIcon = document.createElement('span');
        tooltipIcon.textContent = '(?)';
        tooltipIcon.addEventListener('mouseenter',this.showToolTip.bind(this));
        tooltipIcon.addEventListener('mouseleave',this.hideToolTip.bind(this));
        this.shadowRoot.appendChild(tooltipIcon);
        this.style.position = 'relative';

    }
    showToolTip(){
        this.tooltip = document.createElement('div');
        this.tooltip.textContent = this.toolTipText;
        this.tooltip.style.position = 'absolute';
        this.tooltip.style.zIndex = '10';
        this.tooltip.style.background = 'black';
        this.tooltip.style.color = 'white';
        // this.tooltip.style.border = '1px solid red';   

        this.shadowRoot.appendChild(this.tooltip);
    }
    hideToolTip(){
        this.shadowRoot.removeChild(this.tooltip);
    }
}
//define(how to use custom element(eq to selector),which component)
customElements.define('uc-tooltip',Tooltip);