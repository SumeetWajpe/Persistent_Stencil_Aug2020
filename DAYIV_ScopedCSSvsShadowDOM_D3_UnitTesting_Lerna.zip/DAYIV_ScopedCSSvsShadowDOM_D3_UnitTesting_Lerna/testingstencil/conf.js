exports.config = {
    specs:['./src/full-name-pro.e2e.ts']
}