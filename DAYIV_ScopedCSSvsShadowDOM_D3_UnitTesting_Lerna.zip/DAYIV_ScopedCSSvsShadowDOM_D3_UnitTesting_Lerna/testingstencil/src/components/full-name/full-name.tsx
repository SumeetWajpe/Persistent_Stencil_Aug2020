import { Component, Host, h, Prop } from '@stencil/core';

@Component({
  tag: 'full-name',
  styleUrl: 'full-name.css',
  shadow: true,
})
export class FullName {
  @Prop() firstname:string="Sumeet";
  @Prop() lastname:string="Wajpe";

  render() {
    return (
      <Host>
        <div>
        <h1 class="borderStyle">Mr. {this.firstname} {this.lastname}</h1>
      </div>
      </Host>
     
    );
  }

}
