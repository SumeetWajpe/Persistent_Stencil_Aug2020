import { newE2EPage } from '@stencil/core/testing';

describe('full-name', () => {
  it('renders', async () => {
    const page = await newE2EPage();
    await page.setContent('<full-name></full-name>');

    const element = await page.find('full-name');
    expect(element).toHaveClass('hydrated');
  });
});
