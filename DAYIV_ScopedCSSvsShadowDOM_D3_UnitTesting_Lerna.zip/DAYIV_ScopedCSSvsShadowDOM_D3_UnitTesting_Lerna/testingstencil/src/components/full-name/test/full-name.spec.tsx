import { newSpecPage } from '@stencil/core/testing';
import { FullName } from '../full-name';

describe('full-name', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [FullName],
      html: `<full-name></full-name>`,
    });
    expect(page.root).toEqualHtml(`
      <full-name>
        <mock:shadow-root>
         <div>
            <h1 class="borderStyle">Mr. Sumeet Wajpe</h1>
         </div>
        </mock:shadow-root>
      </full-name>
    `);
  });

  it('reflects the prop value in html',async()=>{
    // arrange // act // assert
    const page = await newSpecPage({
      components: [FullName],
      html: `<div></div>`,
    });
    // window.document.createElement()
    let component = page.doc.createElement('full-name');
    // Act
    component.firstname = "Sachin";
    page.root.appendChild(component);
    await page.waitForChanges();

    // Assert
    expect(page.rootInstance.firstname).toBe("Sachin");

  })
});
