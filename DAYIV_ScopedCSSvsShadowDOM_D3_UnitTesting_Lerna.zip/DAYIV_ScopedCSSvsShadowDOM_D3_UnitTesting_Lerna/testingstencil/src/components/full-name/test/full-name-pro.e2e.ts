import {browser,element, by} from 'protractor';

describe('get classes for h1',()=>{
    beforeEach(()=>{
        browser.get("/");
    });

    it('if h1 gets borderStyle',()=>{
        expect(element(by.css('.borderStyle')).getText()).toContain('Mr. Sumeet Wajpe');
    })
})