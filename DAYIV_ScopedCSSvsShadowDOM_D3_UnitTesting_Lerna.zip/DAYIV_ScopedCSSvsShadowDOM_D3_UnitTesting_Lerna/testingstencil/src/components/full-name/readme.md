# full-name



<!-- Auto Generated Below -->


## Properties

| Property    | Attribute   | Description | Type     | Default    |
| ----------- | ----------- | ----------- | -------- | ---------- |
| `firstname` | `firstname` |             | `string` | `"Sumeet"` |
| `lastname`  | `lastname`  |             | `string` | `"Wajpe"`  |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
