import { Component,  h } from '@stencil/core';
import { countDown } from '../../countdown.worker';
@Component({
  tag: 'web-workers',
  styleUrl: 'web-workers.css',
  shadow: true,
})
export class WebWorkers {


  componentWillLoad() {
    const startNum = 5;
    console.log('start', startNum);

    countDown(startNum, (p) => {
      console.log('progress', p);
    }).then(result => {
      console.log('finish', result);
    });
  }

  render(){
    return<h1> Check console for countdown !</h1>
  }

}
