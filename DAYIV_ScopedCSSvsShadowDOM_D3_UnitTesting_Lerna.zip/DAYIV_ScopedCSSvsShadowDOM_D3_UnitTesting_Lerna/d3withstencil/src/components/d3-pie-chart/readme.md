# d3-pie-chart



<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description | Type     | Default |
| -------- | --------- | ----------- | -------- | ------- |
| `data`   | `data`    |             | `string` | `"[]"`  |
| `height` | `height`  |             | `number` | `400`   |
| `width`  | `width`   |             | `number` | `400`   |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
