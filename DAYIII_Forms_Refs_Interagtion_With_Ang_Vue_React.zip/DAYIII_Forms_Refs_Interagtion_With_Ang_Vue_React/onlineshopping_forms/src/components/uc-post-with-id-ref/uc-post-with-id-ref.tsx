import { Component, Element, h, State } from '@stencil/core';

@Component({
  tag: 'uc-post-with-id-ref',
  styleUrl: 'uc-post-with-id-ref.css',
  shadow: true,
})
export class UcPostWithIdRef {
   @Element() el:HTMLElement;
  postInput:HTMLInputElement;
  @State() thePostId: number = 1;
  @State() thePost:any={};

  GetPostDetails(e:Event){
      e.preventDefault();
      //var theId = this.postInput.value;
      //console.log(theId)
      // without ref   
      this.thePostId = parseInt((this.el.shadowRoot.querySelector('#txtPost') as HTMLInputElement).value);
      fetch(`https://jsonplaceholder.typicode.com/posts/${this.thePostId}`)
      .then(res=>res.json())
      .then(res=>this.thePost = res)
      .catch(err=>console.log(err)) 
    }
  render() {
    return (
      <form onSubmit={this.GetPostDetails.bind(this)}>        
        Enter Post Id : <input type="text" id="txtPost" 
        ref={element=> this.postInput = element} />
        <button>Get Post</button> <br/>
        {this.thePost.title}       
      </form>
    );
  }

}
