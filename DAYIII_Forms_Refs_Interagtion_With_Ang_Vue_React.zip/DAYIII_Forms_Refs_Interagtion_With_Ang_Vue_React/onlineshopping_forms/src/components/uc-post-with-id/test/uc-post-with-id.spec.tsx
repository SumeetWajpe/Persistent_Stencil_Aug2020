import { newSpecPage } from '@stencil/core/testing';
import { UcPostWithId } from '../uc-post-with-id';

describe('uc-post-with-id', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [UcPostWithId],
      html: `<uc-post-with-id></uc-post-with-id>`,
    });
    expect(page.root).toEqualHtml(`
      <uc-post-with-id>
        <mock:shadow-root>
          <slot></slot>
        </mock:shadow-root>
      </uc-post-with-id>
    `);
  });
});
