import { newE2EPage } from '@stencil/core/testing';

describe('uc-post-with-id', () => {
  it('renders', async () => {
    const page = await newE2EPage();
    await page.setContent('<uc-post-with-id></uc-post-with-id>');

    const element = await page.find('uc-post-with-id');
    expect(element).toHaveClass('hydrated');
  });
});
