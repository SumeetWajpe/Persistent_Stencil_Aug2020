import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
      <nav-slider-bar headertitle="React Menu" 
opened={true}>
  <p>State</p>
  <p>Props</p>
  <p>Redux</p>
</nav-slider-bar>
    </div>
  );
}

export default App;
