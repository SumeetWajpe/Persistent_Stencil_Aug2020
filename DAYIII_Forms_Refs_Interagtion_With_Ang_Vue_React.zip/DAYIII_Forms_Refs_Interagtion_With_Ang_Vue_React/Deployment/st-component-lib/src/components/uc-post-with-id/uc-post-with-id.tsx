import { Component, h, State } from '@stencil/core';

@Component({
  tag: 'uc-post-with-id',
  styleUrl: 'uc-post-with-id.css',
  shadow: true,
})
export class UcPostWithId {
  @State() thePostId: number = 1;
  @State() error:any={msg:''} // can be an object
  @State() thePost:any={};
  ErrorMessage:string=" ";
  GetPostDetails(event: Event) {
    event.preventDefault();
    console.log('Within GetPostDetails !', this.thePostId);
    fetch(`https://jsonplaceholder.typicode.com/posts/${this.thePostId}`)
    .then(res=>res.json())
    .then(res=>this.thePost = res)
    .catch(err=>console.log(err))
  }

  GetInput(e:Event) {
    let inputId = (e.target as HTMLInputElement).value
    if(inputId == ''){
      // error !
      this.error.msg = "Invalid Id";
    }
    else{
      this.thePostId = +inputId;     
    }  

  }
  render() {
    if(this.error.msg !== ''){
      this.ErrorMessage = <p>Id is required !</p>
    }
    return (
      <form onSubmit={this.GetPostDetails.bind(this)}>
        {/* {this.ErrorMessage} */}
        Enter Post Id : <input type="text" value={this.thePostId} 
        onInput={this.GetInput.bind(this)} />
        <button>Get Post</button> <br/>
        {this.thePost.title}
      </form>
    );
  }
}
