# nav-slider-bar



<!-- Auto Generated Below -->


## Properties

| Property      | Attribute     | Description | Type      | Default     |
| ------------- | ------------- | ----------- | --------- | ----------- |
| `headertitle` | `headertitle` |             | `string`  | `undefined` |
| `opened`      | `opened`      |             | `boolean` | `false`     |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
