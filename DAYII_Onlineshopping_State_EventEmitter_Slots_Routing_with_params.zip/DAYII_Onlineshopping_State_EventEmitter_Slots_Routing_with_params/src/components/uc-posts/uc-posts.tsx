import { Component, Host, h, State } from '@stencil/core';

@Component({
  tag: 'uc-posts',
  styleUrl: 'uc-posts.css',
  shadow: true,
})
export class UcPosts {
  @State() allPosts:any=[];
  componentDidLoad(){   
    fetch('https://jsonplaceholder.typicode.com/posts')
    .then(res=>res.json())
    .then(posts=> this.allPosts = posts)
    .catch(err=>console.log(err))
  }
  render() {
    let allPostsToBecreated = this.allPosts.map(p=><li><stencil-route-link url={`/postdetails/${p.id}`}>{p.title}</stencil-route-link></li>)
    return (
      <Host>
        <h1>All Posts</h1>
        <ul>
          {allPostsToBecreated}
        </ul>
      </Host>
    );
  }

}
