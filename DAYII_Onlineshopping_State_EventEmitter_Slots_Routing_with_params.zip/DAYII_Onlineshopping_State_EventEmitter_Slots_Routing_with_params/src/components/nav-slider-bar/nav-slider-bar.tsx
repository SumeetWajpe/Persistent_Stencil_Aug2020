import { Component, h, Prop } from '@stencil/core';

@Component({
  tag: 'nav-slider-bar',
  styleUrl: 'nav-slider-bar.css',
  shadow: true,
})
export class NavSliderBar {
  @Prop() headertitle:string;
  @Prop({reflect:true}) opened:boolean=false;
  closeNavSliderBar(){
    this.opened = false;
  }

  // called whenever opened changed its value !
  // @Watch('opened')
  // openedValueChanged(newValue,oldValue){
  //   alert('Value of opened changed !'+newValue + " , " + oldValue);
  // }

  render() {
             return [
               <div class="backdrop" onClick={this.closeNavSliderBar.bind(this)}></div>
               ,
               <aside>
                 <header>
                   <h1>{this.headertitle}</h1>
                   <button onClick={this.closeNavSliderBar.bind(this)}>X</button>
                 </header>
                 <main>
                   <slot></slot>
                 </main>
               </aside>
            ]
           }
}
