import { Component, h, Prop, State,Event, EventEmitter } from '@stencil/core';


@Component({
    tag: 'uc-product',
    styleUrl: 'product.css',
    shadow:true
})
export class Product {
    @Prop() productdetails:any;
    @State() currLikes:number;
    // to restrict the event not to leave shadow dom !
    // @Event({composed:false}) deleteProduct:EventEmitter<number>;
    @Event() deleteProduct:EventEmitter<number>;

    constructor(){
      this.currLikes = this.productdetails.likes;
    }
    changeLikes(){
        this.currLikes++;
    }
    render() {    
        return (
          <div class="item">
            <div>
              <h1>{this.productdetails.title}</h1>
              <img src={this.productdetails.ImageUrl}height="100"  width="100"
              />
              <br />
              <strong>Price : </strong> {this.productdetails.price} <br />
              <strong>Quantity : </strong> {this.productdetails.quantity}{" "}
              <br />
              <strong>Rating : </strong> {this.productdetails.rating} <br />
              <button onClick={this.changeLikes.bind(this)} class="likesbtn">                
                {this.currLikes}
              </button> 
              <button class="deletebtn" onClick={()=>this.deleteProduct.emit(this.productdetails.id)}>
                  Delete
                </button>             
              <br />
            </div>
          </div>
        );
      }
}