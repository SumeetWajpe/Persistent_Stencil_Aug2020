import { Component, Host, h, Prop } from '@stencil/core';
import { MatchResults, RouterHistory } from '@stencil/router';

@Component({
  tag: 'post-details',
  styleUrl: 'post-details.css',
  shadow: true,
})
export class PostDetails {
  @Prop() match:MatchResults;
  @Prop() history:RouterHistory;
  render() {
    return (
      <Host>
        <h1>Post Details for {this.match.params.id}</h1>
        <button onClick={()=>this.history.goBack()}>Go Back</button>
      </Host>
    );
  }

}
