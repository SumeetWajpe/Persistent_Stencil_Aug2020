import { Component, h } from '@stencil/core';


@Component({
    tag: 'uc-app',
    shadow:true
})
export class app {
    
    render() {
        return (
          <stencil-router>
            <stencil-route-switch>
              <stencil-route url="/" component="shopping-cart" exact></stencil-route>
              <stencil-route url="/posts" component="uc-posts"></stencil-route>
              <stencil-route url="/postdetails/:id" component="post-details"></stencil-route>

              {/* <stencil-route url="/dashboard" component="uc-dashboard"></stencil-route>
                    <stencil-route url="/dashboard/posts" component="uc-posts"></stencil-route>
                     */}

              {/* <stencil-route
                url="/dashboard"
                routeRender={() => (
                  <uc-dashboard>
                    <shopping-cart></shopping-cart>                    
                  </uc-dashboard>
                )}
              ></stencil-route>

              <stencil-route
                url="/dashboard/posts"
                routeRender={() => (
                  <uc-dashboard>
                    <uc-posts></uc-posts>
                  </uc-dashboard>
                )}
              ></stencil-route> */}

              {/* <stencil-route component="uc-any"></stencil-route> */}
            </stencil-route-switch>
          </stencil-router>
        );
    }
}